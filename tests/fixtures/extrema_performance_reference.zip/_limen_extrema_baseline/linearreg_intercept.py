import numpy as np
import numpy.typing as npt
import polars as pl

from _limen_extrema_baseline.linearreg import linearreg_components as _linearreg_components


CMP_N_100000 = 100000
CMP_N_2 = 2

def _linearreg_intercept_from_values(values: npt.NDArray[np.float64], period: int) -> npt.NDArray[np.float64]:
    n = len(values)
    out = np.full(n, np.nan, dtype=float)

    lookback_total = period - 1
    if n <= lookback_total:
        return out

    _, b = _linearreg_components(values, period)
    out[lookback_total:] = b

    return out


def linearreg_intercept(
    data: pl.DataFrame,
    price_col: str = 'close',
    period: int = 14,
) -> pl.DataFrame:

    '''
    Compute Linear Regression Intercept.

    Args:
        data (pl.DataFrame): Dataset with input price column
        price_col (str): Column name for input price
        period (int): Number of periods

    Returns:
        pl.DataFrame: The input data with a new column 'linearreg_intercept_{period}'
    '''

    if period < CMP_N_2 or period > CMP_N_100000:
        raise ValueError('linearreg_intercept period must be between 2 and 100000')

    out_col = f"linearreg_intercept_{period}"
    return data.with_columns(
        pl.col(price_col).map_batches(
            lambda s: pl.Series(
                _linearreg_intercept_from_values(
                    s.to_numpy().astype(float, copy=False),
                    period,
                )
            ),
            return_dtype=pl.Float64,
        ).alias(out_col)
    )
