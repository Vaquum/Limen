import numpy as np
import numpy.typing as npt
import polars as pl

from _limen_extrema_baseline._ema import ema_talib_default_segment

CMP_N_100000 = 100000
CMP_N_2 = 2

MACD_COL = 'macd'
MACD_SIGNAL_COL = 'macd_signal'
MACD_HIST_COL = 'macd_hist'


def _macd_from_values(
    values: npt.NDArray[np.float64],
    fast_period: int,
    slow_period: int,
    signal_period: int,
) -> tuple[npt.NDArray[np.float64], npt.NDArray[np.float64], npt.NDArray[np.float64]]:
    n = len(values)
    out_macd = np.full(n, np.nan, dtype=float)
    out_signal = np.full(n, np.nan, dtype=float)
    out_hist = np.full(n, np.nan, dtype=float)

    effective_fast = fast_period
    effective_slow = slow_period
    if effective_slow < effective_fast:
        effective_fast, effective_slow = effective_slow, effective_fast

    lookback_signal = signal_period - 1
    lookback_total = lookback_signal + (effective_slow - 1)
    if n <= lookback_total:
        return out_macd, out_signal, out_hist

    start_idx = lookback_total
    end_idx = n - 1
    ema_start_idx = start_idx - lookback_signal

    _, slow_ema = ema_talib_default_segment(values, effective_slow, ema_start_idx, end_idx)
    _, fast_ema = ema_talib_default_segment(values, effective_fast, ema_start_idx, end_idx)
    macd_buffer = fast_ema - slow_ema

    out_count = n - start_idx
    out_macd[start_idx:] = macd_buffer[lookback_signal:lookback_signal + out_count]

    _, signal_values = ema_talib_default_segment(macd_buffer, signal_period, 0, len(macd_buffer) - 1)
    signal_count = len(signal_values)
    out_signal[start_idx:start_idx + signal_count] = signal_values
    out_hist[start_idx:start_idx + signal_count] = out_macd[start_idx:start_idx + signal_count] - signal_values

    return out_macd, out_signal, out_hist


def macd(
    data: pl.DataFrame,
    price_col: str = 'close',
    fast_period: int = 12,
    slow_period: int = 26,
    signal_period: int = 9,
) -> pl.DataFrame:

    '''
    Compute Moving Average Convergence/Divergence (MACD).

    Args:
        data (pl.DataFrame): Dataset with input price column
        price_col (str): Column name for input price
        fast_period (int): Number of periods for fast EMA (2..100000)
        slow_period (int): Number of periods for slow EMA (2..100000)
        signal_period (int): Number of periods for signal EMA (1..100000)

    Returns:
        pl.DataFrame: The input data with columns 'macd', 'macd_signal', 'macd_hist'
    '''

    if fast_period < CMP_N_2 or fast_period > CMP_N_100000:
        raise ValueError('macd fast_period must be between 2 and 100000')
    if slow_period < CMP_N_2 or slow_period > CMP_N_100000:
        raise ValueError('macd slow_period must be between 2 and 100000')
    if signal_period < 1 or signal_period > CMP_N_100000:
        raise ValueError('macd signal_period must be between 1 and 100000')

    def _macd_struct(series: pl.Series) -> pl.Series:
        values = series.to_numpy().astype(float, copy=False)
        macd_values, signal_values, hist_values = _macd_from_values(
            values,
            fast_period,
            slow_period,
            signal_period,
        )
        return pl.DataFrame({
            MACD_COL: macd_values,
            MACD_SIGNAL_COL: signal_values,
            MACD_HIST_COL: hist_values,
        }).to_struct('__macd_struct')

    macd_expr = pl.col(price_col).map_batches(
        _macd_struct,
        return_dtype=pl.Struct({
            MACD_COL: pl.Float64,
            MACD_SIGNAL_COL: pl.Float64,
            MACD_HIST_COL: pl.Float64,
        }),
    ).alias('__macd_struct')

    return data.with_columns(macd_expr).unnest('__macd_struct')
